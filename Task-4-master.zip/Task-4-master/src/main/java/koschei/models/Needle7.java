package koschei.models;

public class Needle7 {

    @Override
    public String toString() {
        return ", смерть Кощея на игле :( " + "";
    }
}
