package koschei.models;

public class Egg6 {

    @Override
    public String toString() {
        return ", в яйце иголка " + "";
    }
}
