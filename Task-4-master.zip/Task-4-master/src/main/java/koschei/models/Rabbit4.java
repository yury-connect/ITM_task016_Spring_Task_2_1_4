package koschei.models;

import org.springframework.stereotype.Component;

@Component
public class Rabbit4 {

    @Override
    public String toString() {
        return ", в зайце утка " + "";
    }
}
